#5. dwa zbiory, część wspólna bez powtórzeń oraz suma bez powtórzeń

setA = {1,2,2,6,"kot", 9}
setB = {1,5,3,"pies","kot",12}

print("cz. wspolna: ", setA & setB )
print("suma zbiorów: ", setA | setB)